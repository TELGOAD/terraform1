def lambda_handler():
    return {"statusCode" : 200, "body": "Hello from ADT"}